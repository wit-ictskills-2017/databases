##Install MySQL Workbench

###Download MySQL Workbench

Select the appropriate installer for your operating system from the following page: [http://dev.mysql.com/downloads/workbench/5.2.html](http://dev.mysql.com/downloads/workbench/5.2.html) 


###Install MySQL Workbench

Follow the steps in the wizard to install MySQL Workbench.  