##Overview of MySQL terminology

[MySQL Terminology PDF](../archives/MySQL_terminology.pdf)

