##Objectives

- Review basic database concepts

- Overview of MySQL terminology

- Install MySQL Server

- Install MySQL as Windows service

- Install MySQL Workbench

- Create and test connection to server