##Install MySQL Server

###Download MySQL Server Community Edition

Select the appropriate download for your operating system from the following page: [http://www.mysql.com/downloads/mysql/](http://www.mysql.com/downloads/mysql/) 


>![](../img/install1.png)



You will need to create a free account to download the file. 



###Extract the files

- Unzip the downloaded file
- Place the folder in C:\\
- Rename the folder 'mysql' (removing the version number)