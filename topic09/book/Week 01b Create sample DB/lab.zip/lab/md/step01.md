##Review basic database concepts

[Basic Database Concepts PDF](../archives/Basic_Database_Concepts.pdf)




